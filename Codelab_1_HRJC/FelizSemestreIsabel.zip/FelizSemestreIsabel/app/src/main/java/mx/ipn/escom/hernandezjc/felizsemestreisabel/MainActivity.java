package mx.ipn.escom.hernandezjc.felizsemestreisabel;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            //An array start at 0, so the [3] do not exist, triggering the exception
            int[] arr= new int[3];
            int i = arr[3];
            Log.d("MainActivity", "Hola" );

        }catch (Exception e){
            Log.e("MainActivity", "Error, paso algo inesperado");
        }
    }
}