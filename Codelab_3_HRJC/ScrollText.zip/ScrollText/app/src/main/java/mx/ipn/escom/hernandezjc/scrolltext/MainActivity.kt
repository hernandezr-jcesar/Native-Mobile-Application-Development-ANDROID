
package mx.ipn.escom.hernandezjc.scrolltext

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun showMessage(view: View){
        Toast.makeText(this, R.string.toast_message, Toast.LENGTH_SHORT).show()
    }
}