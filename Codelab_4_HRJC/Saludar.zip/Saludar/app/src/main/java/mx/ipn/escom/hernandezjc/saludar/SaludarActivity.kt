package mx.ipn.escom.hernandezjc.saludar

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.EditText
import android.widget.TextView
import mx.ipn.escom.hernandezjc.saludar.MainActivity.Companion.TEXT_REQUEST


class SaludarActivity : AppCompatActivity() {
    private var mReply: EditText? = null

    companion object {
        const val EXTRA_REPLY = "mx.ipn.escom.hernandezjc.saludar.extra.REPLY"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_saludar)
        val intent = intent
        val message = intent.getStringExtra(MainActivity.EXTRA_USERNAME);

        val textView = findViewById<TextView>(R.id.text_message)
        textView.text = message

        mReply = findViewById<EditText>(R.id.editText_second);
    }

    fun returnReply(view: View) {
        val reply = mReply!!.text.toString()
        val replyIntent = Intent()
        replyIntent.putExtra(EXTRA_REPLY, reply)
        setResult(RESULT_OK,replyIntent)
        finish();
    }

}
