package mx.ipn.escom.hernandezjc.saludar

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.TextView





class MainActivity : AppCompatActivity() {
    private var mMessageEditText: EditText? = null
    private var mReplyHeadTextView: TextView? = null
    private var mReplyTextView: TextView? = null

    companion object {
        val TEXT_REQUEST = 1
        private val SALUDAR = MainActivity::class.java.simpleName
        const val EXTRA_USERNAME = "mx.ipn.escom.hernandezjc.saludar.extra.USERNAME"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        mMessageEditText = findViewById<EditText>(R.id.edit_name)
        mReplyHeadTextView = findViewById<TextView>(R.id.text_header_reply);
        mReplyTextView = findViewById<TextView>(R.id.text_message_reply);
    }

    fun SaludarActivity(view: View) {
        Log.d(SALUDAR, "Boton presionado")
        val intent = Intent(this, SaludarActivity::class.java)
        val message = mMessageEditText!!.text.toString()
        intent.putExtra(EXTRA_USERNAME, message)
        startActivityForResult(intent, TEXT_REQUEST);
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // Test for the right intent reply.
        if (requestCode == TEXT_REQUEST) {
            // Test to make sure the intent reply result was good.
            if (resultCode == RESULT_OK) {
                val reply = data?.getStringExtra(SaludarActivity.EXTRA_REPLY)

                // Make the reply head visible.
                mReplyHeadTextView?.visibility = View.VISIBLE

                val tiempo = reply?.toInt()
                var newReply: String? = null

                if (tiempo != null) {
                    when (tiempo) {
                        in 11 downTo 4 -> {
                            newReply = "Buenos días"
                        }
                        in 19 downTo 12 -> {
                            newReply = "Buenas tardes"
                        }
                        else -> {
                            newReply = "Buenas noches"
                        }
                    }
                    // Set the reply and make it visible.
                    mReplyTextView?.text = newReply
                }else{
                    // Set the reply and make it visible.
                    mReplyTextView?.text = reply

                }
            }
                mReplyTextView?.visibility = View.VISIBLE

        }
    }
}
