package mx.ipn.escom.hernandezjc.codelab4codingchallenge

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView

class TextsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_texts)
        val intent = intent
        val numtext = intent.getIntExtra(MainActivity.EXTRA_TEXTO,0)
        val textView = findViewById<TextView>(R.id.Texto)
        val texto1 = getText(R.string.texto_1)
        val texto2 = getText(R.string.texto_2)
        val texto3 = getText(R.string.texto_3)
        when (numtext) {
            1 -> {
                textView.text = texto1
            }
            2 -> {
                textView.text = texto2
            }
            else -> {
                textView.text = texto3
            }
        }





    }
}