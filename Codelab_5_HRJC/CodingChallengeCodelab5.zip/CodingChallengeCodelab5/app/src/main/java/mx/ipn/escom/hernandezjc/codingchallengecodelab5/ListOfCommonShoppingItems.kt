package mx.ipn.escom.hernandezjc.codingchallengecodelab5

import android.app.Activity
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class ListOfCommonShoppingItems : AppCompatActivity() {
    private var buttonReply: Button? = null

    companion object {
        const val EXTRA_REPLY = "mx.ipn.escom.hernandezjc."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_of_common_shopping_items)

    }
    fun returnReply(view: View) {
        var mensaje = intent.getStringExtra("nombre_cadena")

        val buttonText = (view as Button).text.toString()

        mensaje = buttonText

        val intent = Intent()
        intent.putExtra("cadena_introducida", buttonText)
        setResult(Activity.RESULT_OK, intent)
        finish()
    }
}
