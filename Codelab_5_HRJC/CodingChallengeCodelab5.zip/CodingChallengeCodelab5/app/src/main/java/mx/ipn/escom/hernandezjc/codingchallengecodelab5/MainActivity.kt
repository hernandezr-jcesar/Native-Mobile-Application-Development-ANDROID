package mx.ipn.escom.hernandezjc.codingchallengecodelab5

import android.app.Activity
import android.content.Intent
import android.hardware.camera2.CameraDevice
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import android.widget.Toast


class MainActivity : AppCompatActivity() {
    private lateinit var item1: TextView
    private lateinit var item2: TextView
    private lateinit var item3: TextView
    private lateinit var item4: TextView
    private lateinit var item5: TextView
    private lateinit var item6: TextView
    private lateinit var item7: TextView
    private lateinit var item8: TextView
    private lateinit var item9: TextView
    private lateinit var item10: TextView


    companion object {
        private val BOTON = MainActivity::class.java.simpleName
        val codigoSolicitud = 1 // Cualquier número entero
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        item1 = findViewById<TextView>(R.id.textView)
        item2 = findViewById<TextView>(R.id.textView2)
        item3 = findViewById<TextView>(R.id.textView3)
        item4 = findViewById<TextView>(R.id.textView4)
        item5 = findViewById<TextView>(R.id.textView5)
        item6 = findViewById<TextView>(R.id.textView6)
        item7 = findViewById<TextView>(R.id.textView7)
        item8 = findViewById<TextView>(R.id.textView8)
        item9 = findViewById<TextView>(R.id.textView9)
        item10 = findViewById<TextView>(R.id.textView10)



        if (savedInstanceState != null) {
            item1.text = savedInstanceState.getString("item1")
            item2.text = savedInstanceState.getString("item2")
            item3.text = savedInstanceState.getString("item3")
            item4.text = savedInstanceState.getString("item4")
            item5.text = savedInstanceState.getString("item5")
            item6.text = savedInstanceState.getString("item6")
            item7.text = savedInstanceState.getString("item7")
            item8.text = savedInstanceState.getString("item8")
            item9.text = savedInstanceState.getString("item9")
            item10.text = savedInstanceState.getString("item10")
        }

    }
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("item1", item1.text.toString())
        outState.putString("item2", item2.text.toString())
        outState.putString("item3", item3.text.toString())
        outState.putString("item4", item4.text.toString())
        outState.putString("item5", item5.text.toString())
        outState.putString("item6", item6.text.toString())
        outState.putString("item7", item7.text.toString())
        outState.putString("item8", item8.text.toString())
        outState.putString("item9", item9.text.toString())
        outState.putString("item10", item10.text.toString())
    }

    fun IrAListaDeCompras(view: View) {
        Log.d(BOTON, "Boton presionado")


        val intent = Intent(this, ListOfCommonShoppingItems::class.java)
        intent.putExtra("nombre_cadena", "Introduce una cadena:")
        startActivityForResult(intent, codigoSolicitud)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == codigoSolicitud && resultCode == Activity.RESULT_OK) {
            val selectedItem = data?.getStringExtra("cadena_introducida")
            when {
                item1.text.isEmpty() -> item1.text = selectedItem
                item2.text.isEmpty() -> item2.text = selectedItem
                item3.text.isEmpty() -> item3.text = selectedItem
                item4.text.isEmpty() -> item4.text = selectedItem
                item5.text.isEmpty() -> item5.text = selectedItem
                item6.text.isEmpty() -> item6.text = selectedItem
                item7.text.isEmpty() -> item7.text = selectedItem
                item8.text.isEmpty() -> item8.text = selectedItem
                item9.text.isEmpty() -> item9.text = selectedItem
                item10.text.isEmpty() -> item10.text = selectedItem
            }

        }
    }

}