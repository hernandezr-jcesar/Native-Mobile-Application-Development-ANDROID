package mx.ipn.escom.hernandezjc.CicloDeVida

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.TextView


class SaludarActivity : AppCompatActivity() {
    private var mReply: EditText? = null

    companion object {
        const val EXTRA_REPLY = "mx.ipn.escom.hernandezjc.CicloDeVida.extra.REPLY"
        private val LOG_TAG = SaludarActivity::class.java.simpleName

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_saludar)
        val intent = intent
        val message = intent.getStringExtra(MainActivity.EXTRA_USERNAME);

        val textView = findViewById<TextView>(R.id.text_message)
        textView.text = message

        mReply = findViewById<EditText>(R.id.editText_second);
    }

    override fun onStart() {
        super.onStart()
        Log.d(LOG_TAG, "onStart")
    }
    override fun onPause() {
        super.onPause()
        Log.d(LOG_TAG, "onPause")
    }
    override fun onRestart() {
        super.onRestart()
        Log.d(LOG_TAG, "onRestart")
    }
    override fun onResume() {
        super.onResume()
        Log.d(LOG_TAG, "onResume")
    }
    override fun onStop() {
        super.onStop()
        Log.d(LOG_TAG, "onStop")
    }
    override fun onDestroy() {
        super.onDestroy()
        Log.d(LOG_TAG, "onDestroy")
    }


    fun returnReply(view: View) {
        val reply = mReply!!.text.toString()
        val replyIntent = Intent()
        replyIntent.putExtra(EXTRA_REPLY, reply)
        setResult(RESULT_OK,replyIntent)
        Log.d(LOG_TAG, "End SecondActivity");
        finish();
    }

}
