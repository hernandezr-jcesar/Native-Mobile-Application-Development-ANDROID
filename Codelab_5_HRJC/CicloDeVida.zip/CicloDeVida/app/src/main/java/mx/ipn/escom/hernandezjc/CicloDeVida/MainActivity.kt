package mx.ipn.escom.hernandezjc.CicloDeVida

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.TextView


class MainActivity : AppCompatActivity() {
    private var mMessageEditText: EditText? = null
    private var mReplyHeadTextView: TextView? = null
    private var mReplyTextView: TextView? = null

    companion object {
        val TEXT_REQUEST = 1
        private val SALUDAR = MainActivity::class.java.simpleName
        const val EXTRA_USERNAME = "mx.ipn.escom.hernandezjc.CicloDeVida.extra.USERNAME"

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Log.d(SALUDAR, "-------")
        Log.d(SALUDAR, "onCreate");

        // Initialize all the view variables.
        mMessageEditText = findViewById<EditText>(R.id.edit_name)
        mReplyHeadTextView = findViewById<TextView>(R.id.text_header_reply);
        mReplyTextView = findViewById<TextView>(R.id.text_message_reply);

        // Restore the state.
        if (savedInstanceState != null) {
            val isVisible = savedInstanceState.getBoolean("reply_visible")
            if (isVisible) {
                mReplyHeadTextView?.visibility = View.VISIBLE;
                mReplyTextView?.text = savedInstanceState.getString("reply_text");
                mReplyTextView?.visibility = View.VISIBLE;
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        // If the heading is visible, message needs to be saved.
        // Otherwise we're still using default layout.
        if (mReplyHeadTextView?.visibility == View.VISIBLE ) {
            outState.putBoolean("reply_visible", true);
            outState.putString("reply_text",mReplyTextView?.text.toString());
        }
    }
    override fun onStart() {
        super.onStart()
        Log.d(SALUDAR, "onStart")
    }
    override fun onPause() {
        super.onPause()
        Log.d(SALUDAR, "onPause")
    }
    override fun onRestart() {
        super.onRestart()
        Log.d(SALUDAR, "onRestart")
    }
    override fun onResume() {
        super.onResume()
        Log.d(SALUDAR, "onResume")
    }
    override fun onStop() {
        super.onStop()
        Log.d(SALUDAR, "onStop")
    }
    override fun onDestroy() {
        super.onDestroy()
        Log.d(SALUDAR, "onDestroy")
    }



    fun SaludarActivity(view: View) {
        Log.d(SALUDAR, "Boton presionado")
        val intent = Intent(this, SaludarActivity::class.java)
        val message = mMessageEditText!!.text.toString()
        intent.putExtra(EXTRA_USERNAME, message)
        startActivityForResult(intent, TEXT_REQUEST);
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // Test for the right intent reply.
        if (requestCode == TEXT_REQUEST) {
            // Test to make sure the intent reply result was good.
            if (resultCode == RESULT_OK) {
                val reply = data?.getStringExtra(SaludarActivity.EXTRA_REPLY)

                // Make the reply head visible.
                mReplyHeadTextView?.visibility = View.VISIBLE

                val tiempo = reply?.toInt()
                var newReply: String? = null

                if (tiempo != null) {
                    when (tiempo) {
                        in 11 downTo 4 -> {
                            newReply = "Buenos días"
                        }
                        in 19 downTo 12 -> {
                            newReply = "Buenas tardes"
                        }
                        else -> {
                            newReply = "Buenas noches"
                        }
                    }
                    // Set the reply and make it visible.
                    mReplyTextView?.text = newReply
                }else{
                    // Set the reply and make it visible.
                    mReplyTextView?.text = reply

                }
            }
                mReplyTextView?.visibility = View.VISIBLE

        }
    }
}
